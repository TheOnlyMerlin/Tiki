<?php

class fooCustomTransport extends ezcWebdavTransport
{
}

class fooCustomXmlTool extends ezcWebdavXmlTool
{
}

class fooCustomPropertyHandler extends ezcWebdavPropertyHandler
{
}

class fooCustomHeaderHandler extends ezcWebdavHeaderHandler
{
}

?>
