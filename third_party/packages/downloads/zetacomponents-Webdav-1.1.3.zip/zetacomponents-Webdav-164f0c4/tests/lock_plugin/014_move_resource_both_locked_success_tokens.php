<?php

return array(
    'foo' => array(
        'opaquelocktoken:1234' => true,
        'opaquelocktoken:5678' => true,
    ),
);

?>
