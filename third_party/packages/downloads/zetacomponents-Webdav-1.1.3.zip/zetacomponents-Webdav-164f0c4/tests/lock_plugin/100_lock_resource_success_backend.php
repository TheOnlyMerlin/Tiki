<?php

$backendBefore = new ezcWebdavMemoryBackend();

return $backendBefore;

?>
