<?php

return array(
    'foo' => array(
        'opaquelocktoken:1234' => true,
    ),
);

?>
